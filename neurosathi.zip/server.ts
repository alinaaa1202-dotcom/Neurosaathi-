import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";
import {
  runAgentConversation,
  ALL_COGNITIVE_GAMES,
  NEUROSATHI_AGENT_TOOLS,
  serverSupabase,
  isUuid,
} from "./server/agent";
import { resolveResponseLanguage } from "./src/lib/languageRouter";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialized GoogleGenAI client
let genAI: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  if (!genAI) {
    genAI = new GoogleGenAI({ apiKey });
  }
  return genAI;
}

// Health check endpoint
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    hasGeminiKey: Boolean(process.env.GEMINI_API_KEY),
    supabaseConnected: Boolean(serverSupabase),
    timestamp: new Date().toISOString(),
  });
});

// List games endpoint
app.get("/api/games", (req, res) => {
  res.json({ games: Object.values(ALL_COGNITIVE_GAMES) });
});

// List agent tools endpoint
app.get("/api/tools", (req, res) => {
  res.json({
    tools: NEUROSATHI_AGENT_TOOLS.map((t) => ({
      name: t.name,
      description: t.description,
    })),
  });
});

// Gemini AI Chat & Agent endpoint
app.post("/api/chat", async (req, res) => {
  try {
    const {
      message,
      history = [],
      language = "English",
      userRole = "patient",
      userName = "Friend",
      userId,
      userContext,
    } = req.body;

    if (!message || typeof message !== "string") {
      return res.status(400).json({ error: "A message string is required." });
    }

    // Resolve language through centralized Language Router (Priority 1: Explicit, Priority 2: Detected, Priority 3: Selected, Priority 4: Fallback)
    const resolvedLang = resolveResponseLanguage({
      text: message,
      selectedLanguage: language,
      preferredLanguage: userContext?.preferredLanguage,
      history,
    });

    const ai = getGenAI();

    // If Gemini key is missing, return friendly fallback in resolved language
    if (!ai) {
      const isHindi =
        resolvedLang.resolvedCode === "hi" ||
        resolvedLang.resolvedName.toLowerCase().includes("hindi");
      const fallbackReply = isHindi
        ? `नमस्ते ${userName} जी! मैं न्यूरोसाथी हूँ। मैं आपकी याददाश्त, सेहत और दैनिक दिनचर्या में मदद करने के लिए यहाँ हूँ। कृपया अपना सवाल पूछें।`
        : `Hello ${userName}! I am NeuroSathi, your cognitive companion. I am here to support your memory, health reminders, and daily well-being. How can I assist you today?`;

      return res.json({
        reply: fallbackReply,
        launchGame: null,
        simulated: true,
        resolvedLanguage: resolvedLang,
      });
    }

    // Run the agentic Gemini conversation with tool reasoning
    const agentResult = await runAgentConversation(ai, {
      message,
      history,
      language,
      userName,
      userRole,
      userId,
      userContext,
      resolvedLanguageResult: resolvedLang,
    });

    const finalResolvedCode =
      agentResult.resolvedLanguage?.resolvedCode || resolvedLang.resolvedCode || "en";

    // If user issued an explicit language change command, persist preference to Supabase profiles
    if (
      serverSupabase &&
      userId &&
      isUuid(userId) &&
      (resolvedLang.shouldUpdatePreference || agentResult.resolvedLanguage?.shouldUpdatePreference)
    ) {
      try {
        await serverSupabase
          .from("profiles")
          .update({ preferred_language: finalResolvedCode })
          .eq("id", userId);
      } catch (prefErr) {
        console.warn("Could not persist preferred_language to profiles:", prefErr);
      }
    }

    // Automatically persist to Supabase ai_history with resolved language
    if (serverSupabase && userId && isUuid(userId)) {
      try {
        await serverSupabase.from("ai_history").insert([
          { user_id: userId, role: "user", message, language: finalResolvedCode },
          { user_id: userId, role: "model", message: agentResult.reply, language: finalResolvedCode },
        ]);
      } catch (dbErr) {
        console.warn("Could not record turn to Supabase ai_history:", dbErr);
      }
    }

    res.json({
      ...agentResult,
      resolvedLanguage: agentResult.resolvedLanguage || resolvedLang,
    });
  } catch (err: any) {
    console.error("Gemini Agent Chat Error:", err);
    res.status(500).json({
      error: "Failed to generate AI response",
      details: err.message || String(err),
    });
  }
});

async function startServer() {
  // Vite dev server integration
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`NeuroSathi Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
