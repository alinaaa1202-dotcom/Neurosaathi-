/**
 * NeuroSathi Translation & Cross-Lingual Bridge Service
 * 
 * Manages translation assistance for tier-2 (translation-supported) languages
 * ensuring that the Gemini Agent can comfortably reason in low-resource dialects
 * without exposing intermediate translation artifacts to the patient or caregiver.
 */

import { GoogleGenAI } from "@google/genai";
import { getLanguageCapability, LanguageCapability } from "./languageCapabilities";

export interface TranslationContext {
  sourceLanguage: string;
  targetLanguage: string;
  isDirectGemini: boolean;
}

/**
 * Prepares dynamic translation guidelines for the Gemini Agent's system instruction
 */
export function buildTranslationSystemDirective(targetLang: LanguageCapability): string {
  if (targetLang.geminiDirect) {
    return `TARGET RESPONSE LANGUAGE: ${targetLang.name} (${targetLang.nativeName})
- You have direct, fluent generation capability in ${targetLang.name}.
- Formulate your complete final answer directly in ${targetLang.name}.
- Do NOT output English translations or meta-commentary alongside your response.`;
  }

  // Translation-assisted tier (e.g. Maithili, Dogri, Bodo, Santali, Manipuri, Konkani, Kashmiri, Sanskrit)
  return `TARGET RESPONSE LANGUAGE: ${targetLang.name} (${targetLang.nativeName}) [Translation-Assisted Tier]
- The user requires response in ${targetLang.name}.
- Internal cognitive reasoning may use the language's native vocabulary with Hindi/regional grammar bridging.
- Deliver the final answer strictly in authentic ${targetLang.name} with respectful phrasing.
- NEVER expose internal translation tokens, English scratchpads, or system explanations to the user.`;
}

/**
 * Checks if a language requires special translation bridging
 */
export function requiresTranslationBridge(langCodeOrName: string): boolean {
  const cap = getLanguageCapability(langCodeOrName);
  return !cap.geminiDirect && cap.translationSupported;
}

/**
 * Server-side optional bridge helper if a secondary translation pass is ever requested
 */
export async function translateTextWithGemini(
  ai: GoogleGenAI,
  text: string,
  targetLangCode: string
): Promise<string> {
  const targetCap = getLanguageCapability(targetLangCode);
  if (targetCap.code === "en" || !text.trim()) {
    return text;
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-lite",
      contents: [
        {
          role: "user",
          parts: [
            {
              text: `Translate the following text accurately, warmly, and naturally into ${targetCap.name} (${targetCap.nativeName}) for an elderly healthcare patient. Output ONLY the translated text without notes, phonetic keys, or quotes:\n\n${text}`,
            },
          ],
        },
      ],
    });

    return response.text?.trim() || text;
  } catch (err) {
    console.warn("Translation bridge fallback:", err);
    return text;
  }
}
